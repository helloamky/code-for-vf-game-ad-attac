import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public class Main {
    private static int score = 0;
    private static JLabel scoreLabel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame mainWindow = createAndShowGUI();
            JButton startGameButton = new JButton("Start Game");
            scoreLabel = new JLabel("Score: " + score);
            startGameButton.addActionListener(e -> openGameWindow(mainWindow));
            JPanel mainPanel = new JPanel(new FlowLayout());
            mainPanel.add(startGameButton);
            mainPanel.add(scoreLabel);
            mainWindow.add(mainPanel);
            mainWindow.setVisible(true);
        });
    }

    private static JFrame createAndShowGUI() {
        JFrame frame = new JFrame("ADS-ATTACK");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setResizable(false);
        frame.setAlwaysOnTop(true);
        return frame;
    }

    private static void openGameWindow(JFrame mainWindow) {
        JFrame gameWindow = new JFrame("CLOSE ME!!! >:)");
        setupGameWindow(gameWindow, mainWindow);
        gameWindow.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent windowEvent) {
                score += 1;
                scoreLabel.setText("Score: " + score);
                openGameWindow(mainWindow);
            }
        });

        Random random = new Random();
        int screenWidth = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        int screenHeight = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        int windowWidth = 400;
        int windowHeight = 300;
        int x = random.nextInt(screenWidth - windowWidth);
        int y = random.nextInt(screenHeight - windowHeight);
        gameWindow.setLocation(x, y);

        File folder = new File("src/memes");
        File[] files = folder.listFiles((dir, name) ->
                name.toLowerCase().endsWith(".png") || name.toLowerCase().endsWith(".jpg") ||
                        name.toLowerCase().endsWith(".mp4") || name.toLowerCase().endsWith(".avi"));

        if (files != null && files.length > 0) {
            int randomIndex = random.nextInt(files.length);
            File selectedFile = files[randomIndex];
            if (selectedFile.getName().toLowerCase().endsWith(".mp4") ||
                    selectedFile.getName().toLowerCase().endsWith(".avi")) {
                playVideo(selectedFile, gameWindow, windowWidth, windowHeight);
            } else {
                displayImage(selectedFile, gameWindow, windowWidth, windowHeight);
            }
        } else {
            System.err.println("Error: No valid media files found in the specified folder.");
        }

        gameWindow.setVisible(true);
    }

    private static void setupGameWindow(JFrame gameWindow, JFrame mainWindow) {
        gameWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        gameWindow.setResizable(false);
        gameWindow.setAlwaysOnTop(true);
    }

    private static void playVideo(File videoFile, JFrame gameWindow, int windowWidth, int windowHeight) {
        JFXPanel fxPanel = new JFXPanel();
        gameWindow.setContentPane(fxPanel);

        SwingUtilities.invokeLater(() -> {
            Media media = new Media(videoFile.toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);
            mediaPlayer.setAutoPlay(true);
            mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);

            MediaView mediaView = new MediaView(mediaPlayer);
            Scene scene = new Scene(new javafx.scene.layout.StackPane(mediaView), windowWidth, windowHeight);
            fxPanel.setScene(scene);

            double aspectRatio = (double) mediaPlayer.getMedia().getWidth() / mediaPlayer.getMedia().getHeight();
            int newWidth = aspectRatio > 1 ? windowWidth : (int) (windowHeight * aspectRatio);
            int newHeight = aspectRatio > 1 ? (int) (windowWidth / aspectRatio) : windowHeight;
            gameWindow.setSize(newWidth, newHeight);
        });
    }

    private static void displayImage(File imageFile, JFrame gameWindow, int windowWidth, int windowHeight) {
        try {
            Image originalImage = ImageIO.read(imageFile);
            double aspectRatio = (double) originalImage.getWidth(null) / originalImage.getHeight(null);
            int newWidth = aspectRatio > 1 ? windowWidth : (int) (windowHeight * aspectRatio);
            int newHeight = aspectRatio > 1 ? (int) (windowWidth / aspectRatio) : windowHeight;
            Image resizedImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
            JLabel imageLabel = new JLabel(new ImageIcon(resizedImage));
            gameWindow.setContentPane(imageLabel);
            gameWindow.setSize(newWidth, newHeight);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}